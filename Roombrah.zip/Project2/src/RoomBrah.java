import java.awt.Color;

public class RoomBrah {
	
	EZImage Roombrah;										//EZImage for the roombrah
	EZImage Wall[];											//EZImage for the walls
	EZImage Shroom[];										//EZImage for the dirt or shrooms
	EZCircle Path_trace;									//EZCircle for the pathway or trace
	
	EZSound BounceSound = EZ.addSound("Bounce.wav");		//Sound when roombrah bounces
	EZSound ShroomSound = EZ.addSound("1UP.wav");			//Sound when roombrah collects a shroom
	
	int x_position, y_position;								//Will contain the position of the roombrah
	
	int x_dir;												//Will contain the direction of the roombrah in the X axis
	int y_dir;												//Will contain the direction of the roombrah in the Y axis
	
	int wallCount;											//Will contain the number of walls
	int shroomCount;										//Will contain the number of dirt or shrooms
	
	int collected = 0;										//Contains the number of shrooms collected
	
	//Constructor for Roombrah
	RoomBrah(String file_name, EZImage W[], EZImage D[], int wall_count, int dirt_count) {
		Wall = W;
		Shroom = D;
		wallCount = wall_count;
		shroomCount = dirt_count;
		Roombrah = EZ.addImage(file_name, x_position, y_position);
	}
	
	//Sets the Roombrah's position
	public void setPosition(int x_orig, int y_orig) {
		x_position = x_orig;
		y_position = y_orig;
	}
	
	//Sets the Roombrah's direction
	public void direction(int directionX,int directionY) {
		x_dir = directionX;
		y_dir = directionY;
	}
	
	//Moves teh Roombrah
	public void move() {
		x_position = x_position + x_dir;
		y_position = y_position + y_dir;
		Roombrah.translateTo(x_position, y_position);
		Path_trace = EZ.addCircle(getX(), getY(), 4, 4, Color.CYAN, false);
		Path_trace.pushToBack();
	}
	
	//Gets the X center of the Roombrah
	public int getX() {
		return Roombrah.getXCenter();
	}
	
	//Gets the Y center of the Roombrah
	public int getY() {
		return Roombrah.getYCenter();
	}
	
	//Makes the Roombrah collide with the walls
	public void collideWall() {
		for (int i = 0; i < wallCount; i++) {
			if (Wall[i].isPointInElement(getX()+x_dir, getY())) {
				x_dir = -x_dir;
				BounceSound.play();
			}
			if (Wall[i].isPointInElement(getX(), getY()+y_dir)) {
				y_dir = -y_dir;
				BounceSound.play();
			} 
		}
	}
	
	//Makes the Roombrah collect the dirt or shrooms
	public void collideShroom() {
		for (int j = 0; j < shroomCount; j++) {
			
			if (Shroom[j].isPointInElement(getX(), getY())) {
				Shroom[j].translateTo(-32, -32);
				collected++;
				ShroomSound.play();
			}
		}
	}
	
	//Checks if the Roombrah has collected all the dirt of shrooms
	public boolean collectedAll() {
		if (collected == shroomCount) {
			return true;
		}
		return false;
	}
	
}
