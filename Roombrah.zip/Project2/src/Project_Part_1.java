import java.awt.Color;
import java.io.FileReader;
import java.util.Scanner;

public class Project_Part_1 {

	public static void main(String[] args) throws java.io.IOException {								//need throws java.io.IOException, otherwise program won't scan file.txt

		Scanner fileScanner = new Scanner(new FileReader("RoombrahMap.txt"));						//Need this to scan the file RoombrahMap.txt
		
		int columnAmount = fileScanner.nextInt();													//Reads the first integer text from the file which represents the amount of columns
		int rowAmount = fileScanner.nextInt();														//Reads the second integer text from the file which represents the amount of rows
		String input = fileScanner.nextLine();														//Reads the characters, which are letters W and D in this case
		
		EZ.initialize(columnAmount*32, rowAmount*32);												//Sets up the window of the program, we need to multiply by 32 because images are 32x32 pixels
		EZ.setBackgroundColor(Color.BLACK);															//Background color of the program
		
		int countW = 0;																				//Variable that will contain the amount of W characters
		int countD = 0;																				//Variable that will contain the amount of D characters
		
		int x_movement = -3;																		//Variable containing the Roombrah's direction in the x-axis
		int y_movement = 3;																			//Variable containing the Roombrah's direction in the y-axis
		
		EZImage[] Wall = new EZImage[500];															//Array for the walls
		EZImage[] Shroom = new EZImage[500];														//Array for the dirt or shrooms
		
		EZSound BGSound = EZ.addSound("Overworld_1.wav");											//background sound
		EZSound Finish = EZ.addSound("Clear.wav");													//sound when program finishes
				
		for (int rowNum = 0; rowNum < rowAmount; rowNum++) {										//This lets the program read each row one by one
		
			input = fileScanner.nextLine();															//Reads the characters of the file
			System.out.println(input);																//Prints the whole file
			
			for (int columnNum = 0; columnNum < columnAmount; columnNum++) {						//This lets the program read each column one by one per each row
				
				char character = input.charAt(columnNum);											//returns the character value from the column number it's from
				
				switch (character) {																//switch function enables us to create conditions for each character, instead of multiple if-statements
					case 'W':
						Wall[countW] = EZ.addImage("Block.png", columnNum*32+16, rowNum*32+16);		//adds block image when it reads 'W' character
						countW++;																	//Counts the W; it increases each time it reads another W										
						break;
					case 'D':
						Shroom[countD] = EZ.addImage("1up.png", columnNum*32+16, rowNum*32+16);		//adds block image when it reads 'D' character
						countD++;																	//Counts the D; it increases each time it reads another D												
						break;
					default:																		//If it doesn't read either W or D, then it moves on to the
						break;																		//next column
				}
			}
		}
		
		fileScanner.close();																		//closes the file scanner
		
		System.out.println("Amount of Walls: " + countW);											//prints the amount of blocks (W)
		System.out.println("Amount of Shrooms: " + countD);											//prints the amount of mushrooms (D)
		
		RoomBrah Roombrah = new RoomBrah("Mario.png", Wall, Shroom, countW, countD);				//the Roombrah object
		Roombrah.setPosition(750, 50);																//sets the Roombrah's position
		Roombrah.direction(x_movement, y_movement);													//sets the Roombrah's direction

		BGSound.loop();																				//background sound loops until program ends
		
		while (true) {																				//need this to keep the program running
			
			Roombrah.move();																		//moves the Roombrah
			
			Roombrah.collideWall();																	//makes the Roombrah bounce off the walls																
			
			if (!Roombrah.collectedAll()) {															//condition that stops the program when collected all shrooms
				Roombrah.collideShroom();															//makes the Roombrah collect shrooms
			} else {
				break;
			}
			
		/*=================The following code is when you want to use collideWall and collideShroom function in the main==================	
			
			for (int i = 0; i < countW; i++) {
				
				if (Wall[i].isPointInElement(Roombrah.getX()+x_movement, Roombrah.getY())) {
					x_movement = -x_movement;
				}
				
				if (Wall[i].isPointInElement(Roombrah.getX(), Roombrah.getY()+y_movement)) {
					y_movement = -y_movement;
				}
				
			}
			
			for (int j = 0; j < countD; j++) {
				
				if (Shroom[j].isPointInElement(Roombrah.getX(), Roombrah.getY())) {
					Shroom[j].translateTo(-32, -32);
					
				}
			}
			===============================================================================================================================*/
			
			EZ.refreshScreen();																		//refreshes the screen to constantly make changes visible
		}
		BGSound.stop();																				//background sound stops
		Finish.play();																				//ending-music plays
		
	}
}
